import React from "react";
import "./Navbar.css";

export default function Navbar() {
  return (
    <nav className="navbar">
      <h1>InterviewAI</h1>
    </nav>
  );
}
