import React from "react";
import { useNavigate } from "react-router-dom";

const Welcome = () => {
  const navigate = useNavigate();

  const handleStart = () => {
    navigate("/dashboard");
  };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        height: "100vh",
        background: "linear-gradient(135deg, #89f7fe, #66a6ff)",
        fontFamily: "Poppins, sans-serif",
      }}
    >
      <h1
        style={{
          fontSize: "3rem",
          fontWeight: "bold",
          color: "#fff",
          marginBottom: "10px",
        }}
      >
        🎯 Welcome to InterviewAI
      </h1>
      <p
        style={{
          fontSize: "1.3rem",
          color: "rgba(255,255,255,0.9)",
          maxWidth: "600px",
          textAlign: "center",
          lineHeight: "1.6",
          marginBottom: "30px",
        }}
      >
        Your personal AI-powered interview assistant.  
        Practice answering real interview questions, get instant feedback,  
        and improve your confidence — one response at a time.
      </p>
      <button
        onClick={handleStart}
        style={{
          background: "#fff",
          color: "#007bff",
          padding: "15px 35px",
          fontSize: "18px",
          borderRadius: "30px",
          border: "none",
          cursor: "pointer",
          boxShadow: "0px 5px 15px rgba(0,0,0,0.2)",
          transition: "all 0.3s ease",
        }}
        onMouseOver={(e) => (e.target.style.transform = "scale(1.05)")}
        onMouseOut={(e) => (e.target.style.transform = "scale(1)")}
      >
        🚀 Start Interview
      </button>
    </div>
  );
};

export default Welcome;
