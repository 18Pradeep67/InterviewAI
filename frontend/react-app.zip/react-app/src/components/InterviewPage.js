import React, { useState, useRef } from "react";

const InterviewPage = () => {
  const [recording, setRecording] = useState(false);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [videoBlob, setVideoBlob] = useState(null);

  const questions = [
    "Tell me about yourself.",
    "What are your strengths and weaknesses?",
    "Why do you want to work here?",
  ];

  const mediaRecorderRef = useRef(null);
  const videoRef = useRef(null);
  const chunks = useRef([]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      videoRef.current.srcObject = stream;

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.ondataavailable = (e) => chunks.current.push(e.data);
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks.current, { type: "video/webm" });
        setVideoBlob(blob);
        chunks.current = [];
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setRecording(true);
    } catch (err) {
      console.error("Error starting video recording:", err);
      alert("Could not access your camera or microphone.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setRecording(false);
    }
  };

  const handleNextQuestion = () => {
    stopRecording();
    if (questionIndex < questions.length - 1) {
      setQuestionIndex((prev) => prev + 1);
    } else {
      alert("Interview completed!");
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gray-100 p-6">
      <div className="bg-white rounded-2xl shadow-lg w-full max-w-3xl p-8 text-center">
        <h1 className="text-3xl font-semibold mb-4 text-indigo-600">
          Virtual Interview
        </h1>
        <p className="text-lg mb-6 text-gray-700">
          Question {questionIndex + 1} of {questions.length}
        </p>
        <div className="bg-gray-50 p-4 rounded-xl mb-6 border border-gray-200">
          <h2 className="text-xl font-medium text-gray-800">
            {questions[questionIndex]}
          </h2>
        </div>

        <div className="flex flex-col items-center gap-4">
          <video
            ref={videoRef}
            autoPlay
            muted
            className="w-96 h-64 bg-black rounded-xl border border-gray-300"
          />

          <div className="flex gap-4 mt-4">
            {!recording ? (
              <button
                onClick={startRecording}
                className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg transition"
              >
                🎥 Start Recording
              </button>
            ) : (
              <button
                onClick={stopRecording}
                className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-lg transition"
              >
                ⏹ Stop Recording
              </button>
            )}

            <button
              onClick={handleNextQuestion}
              disabled={recording}
              className={`px-6 py-2 rounded-lg transition ${
                recording
                  ? "bg-gray-300 text-gray-500"
                  : "bg-indigo-500 hover:bg-indigo-600 text-white"
              }`}
            >
              {questionIndex < questions.length - 1 ? "Next Question" : "Finish"}
            </button>
          </div>

          {videoBlob && (
            <div className="mt-6 w-full text-center">
              <h3 className="text-lg font-medium text-gray-700 mb-2">
                Recorded Clip Preview:
              </h3>
              <video
                controls
                src={URL.createObjectURL(videoBlob)}
                className="w-96 h-64 rounded-lg border border-gray-300"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default InterviewPage;
