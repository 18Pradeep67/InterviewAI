import React, { useRef, useState } from "react";

const CameraRecorder = ({ onStopRecording }) => {
  const videoRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const [recording, setRecording] = useState(false);
  const [stream, setStream] = useState(null);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      setStream(mediaStream);
      videoRef.current.srcObject = mediaStream;
    } catch (error) {
      console.error("Camera access denied:", error);
    }
  };

  const startRecording = () => {
    if (!stream) return;
    const mediaRecorder = new MediaRecorder(stream);
    const chunks = [];
    mediaRecorder.ondataavailable = (event) => chunks.push(event.data);
    mediaRecorder.onstop = () => {
      const blob = new Blob(chunks, { type: "video/webm" });
      onStopRecording(blob);
    };
    mediaRecorder.start();
    mediaRecorderRef.current = mediaRecorder;
    setRecording(true);
  };

  const stopRecording = () => {
    mediaRecorderRef.current.stop();
    setRecording(false);
  };

  return (
    <div style={{ textAlign: "center" }}>
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        width="480"
        height="360"
        style={{ borderRadius: "10px", border: "2px solid #ccc" }}
      />
      <div style={{ marginTop: "10px" }}>
        {!stream ? (
          <button onClick={startCamera}>Start Camera</button>
        ) : !recording ? (
          <button onClick={startRecording}>🎙 Start Recording</button>
        ) : (
          <button onClick={stopRecording}>⏹ Stop Recording</button>
        )}
      </div>
    </div>
  );
};

export default CameraRecorder;
