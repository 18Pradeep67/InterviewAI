import React, { useState, useEffect, useRef } from "react";

const Dashboard = () => {
  const [currentPage, setCurrentPage] = useState("welcome");
  const [recording, setRecording] = useState(false);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [videoBlob, setVideoBlob] = useState(null);
  const [audioPlaying, setAudioPlaying] = useState(false);

  const mediaRecorderRef = useRef(null);
  const videoRef = useRef(null);
  const chunks = useRef([]);

  const questions = [
    {
      text: "Tell me about yourself.",
      audio: "/audios/q1.mp3",
    },
    {
      text: "What are your strengths and weaknesses?",
      audio: "/audios/q2.mp3",
    },
    {
      text: "Why do you want to work here?",
      audio: "/audios/q3.mp3",
    },
  ];

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      videoRef.current.srcObject = stream;

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (e) => chunks.current.push(e.data);
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks.current, { type: "video/webm" });
        setVideoBlob(blob);
        chunks.current = [];
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setRecording(true);
    } catch (err) {
      console.error("Camera/Mic access error:", err);
      alert("Could not access camera or microphone.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setRecording(false);
    }
  };

  const playQuestionAudio = (src) => {
    const audio = new Audio(src);
    audio.loop = false; // ✅ prevents looping
    audio.play();
    setAudioPlaying(true);
    audio.onended = () => setAudioPlaying(false);
  };

  const handleNextQuestion = () => {
    stopRecording();
    if (questionIndex < questions.length - 1) {
      setQuestionIndex((prev) => prev + 1);
      playQuestionAudio(questions[questionIndex + 1].audio);
    } else {
      setCurrentPage("summary");
    }
  };

  const handleStartInterview = () => {
    setCurrentPage("interview");
    playQuestionAudio(questions[0].audio);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-100 via-white to-indigo-50 font-sans">
      {/* ---------- WELCOME PAGE ---------- */}
      {currentPage === "welcome" && (
        <div className="bg-white shadow-xl rounded-2xl p-10 text-center w-[500px]">
          <h1 className="text-4xl font-bold text-indigo-700 mb-4">Welcome 👋</h1>
          <p className="text-gray-600 mb-6">
            Ready to start your AI-powered mock interview? You’ll answer live
            questions while your responses are recorded and analyzed.
          </p>
          <button
            onClick={handleStartInterview}
            className="bg-indigo-600 text-white px-6 py-3 rounded-xl shadow hover:bg-indigo-700 transition"
          >
            Start Interview
          </button>
        </div>
      )}

      {/* ---------- INTERVIEW PAGE ---------- */}
      {currentPage === "interview" && (
        <div className="bg-white shadow-2xl rounded-2xl p-8 w-[650px] text-center">
          <h2 className="text-2xl font-semibold text-indigo-700 mb-3">
            Question {questionIndex + 1} of {questions.length}
          </h2>
          <p className="text-lg text-gray-700 mb-6">
            {questions[questionIndex].text}
          </p>

          <div className="flex flex-col items-center space-y-4">
            <video
              ref={videoRef}
              autoPlay
              muted
              className="w-[500px] h-[320px] rounded-xl border border-gray-200 shadow"
            ></video>

            <div className="space-x-4">
              {!recording ? (
                <button
                  onClick={startRecording}
                  disabled={audioPlaying}
                  className="bg-green-600 text-white px-5 py-2 rounded-xl hover:bg-green-700 transition"
                >
                  🎥 Start Recording
                </button>
              ) : (
                <button
                  onClick={stopRecording}
                  className="bg-red-600 text-white px-5 py-2 rounded-xl hover:bg-red-700 transition"
                >
                  ⏹ Stop Recording
                </button>
              )}

              <button
                onClick={handleNextQuestion}
                disabled={recording}
                className="bg-indigo-600 text-white px-5 py-2 rounded-xl hover:bg-indigo-700 transition"
              >
                Next Question
              </button>
            </div>
          </div>

          {videoBlob && (
            <div className="mt-8">
              <h4 className="text-lg font-semibold text-gray-800 mb-2">
                Preview of Your Response:
              </h4>
              <video
                controls
                src={URL.createObjectURL(videoBlob)}
                className="w-[500px] rounded-xl shadow"
              />
            </div>
          )}
        </div>
      )}

      {/* ---------- SUMMARY PAGE ---------- */}
      {currentPage === "summary" && (
        <div className="bg-white shadow-xl rounded-2xl p-10 text-center w-[500px]">
          <h2 className="text-3xl font-bold text-indigo-700 mb-4">
            🎉 Interview Completed!
          </h2>
          <p className="text-gray-600 mb-6">
            Your responses have been recorded successfully. The AI will analyze
            them and generate your detailed performance report.
          </p>
          <button
            onClick={() => setCurrentPage("welcome")}
            className="bg-indigo-600 text-white px-6 py-3 rounded-xl shadow hover:bg-indigo-700 transition"
          >
            Back to Dashboard
          </button>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
