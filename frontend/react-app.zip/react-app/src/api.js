// src/api.js

// 👇 Update this if your FastAPI backend runs elsewhere
const API_BASE = "http://127.0.0.1:8000"; 

// --- LOGIN ---
export async function loginUser(email, password) {
  try {
    const response = await fetch(`${API_BASE}/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    });

    if (!response.ok) {
      throw new Error("Login failed");
    }

    return await response.json();
  } catch (error) {
    console.error("Error logging in:", error);
    throw error;
  }
}

// --- SIGNUP ---
export async function signupUser(email, password) {
  try {
    const response = await fetch(`${API_BASE}/signup`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    });

    if (!response.ok) {
      throw new Error("Signup failed");
    }

    return await response.json();
  } catch (error) {
    console.error("Error signing up:", error);
    throw error;
  }
}
